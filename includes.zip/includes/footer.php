<footer>
	<div class="container">
		Copyright <span class="glyphicon glyphicon-copyright-mark"></span> LifeStyle Stores.
		All Rights Reserved | Contact Us: +91 90000 00000
	</div>
</footer>